# Darkfb.v4

$pkg update && pkg upgrade

$pkg install python2

$pip2 install --upgrade pip

$pkg install git

$pip2 install mechanize

$pip2 install requests

$git clone https://github.com/kangcoli/Anjing

$ls

$cd Anjing

$python2 Anjing.py


Download Lisensinya Disini : https://autoratio.com/ognC
